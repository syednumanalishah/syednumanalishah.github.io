#!/usr/bin/env python3
"""Local/live-preview server. Static hosting needs no Python server."""
import argparse
import html
import re
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from content import SERVICES

ROOT = Path(__file__).resolve().parent
PAGES = ['/', '/services/', '/about/', '/contact/', '/privacy/'] + [f"/services/{s['slug']}/" for s in SERVICES]

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def origin(self):
        host = self.headers.get('X-Forwarded-Host', self.headers.get('Host', 'localhost')).split(',')[0].strip()
        if not re.fullmatch(r'[A-Za-z0-9.\-:]+', host):
            host = 'localhost'
        proto = self.headers.get('X-Forwarded-Proto', 'http').split(',')[0].strip().lower()
        if proto not in ('http','https'):
            proto = 'http'
        return f'{proto}://{host}'

    def write_response(self, body, content_type):
        encoded = body.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(encoded)))
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(encoded)

    def handle_special(self):
        path = urlsplit(self.path).path
        if path == '/sitemap.xml':
            origin = self.origin()
            urls = ''.join(f'  <url><loc>{html.escape(origin + p)}</loc></url>\n' for p in PAGES)
            self.write_response('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+urls+'</urlset>\n', 'application/xml; charset=utf-8')
            return True
        if path == '/robots.txt':
            self.write_response(f'User-agent: *\nAllow: /\nSitemap: {self.origin()}/sitemap.xml\n', 'text/plain; charset=utf-8')
            return True
        return False

    def end_headers(self):
        # Temporary previews should not compete with the owner's eventual public site.
        self.send_header("X-Robots-Tag", "noindex, nofollow")
        super().end_headers()

    def do_GET(self):
        if not self.handle_special():
            super().do_GET()

    def do_HEAD(self):
        if not self.handle_special():
            super().do_HEAD()

    def list_directory(self, path):
        self.send_error(404, 'File not found')
        return None

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=3000)
    args = parser.parse_args()
    print(f'Website preview running on port {args.port}', flush=True)
    ThreadingHTTPServer(('0.0.0.0', args.port), Handler).serve_forever()
