# عامل بابا نعمان علی شاہ — Website

ایک تیز رفتار، ریسپانسیو، اردو نستعلیق ویب سائٹ۔ ۱۶ خدمات کے اپنے الگ، سرچ انجن کے لیے قابلِ مطالعہ صفحات ہیں۔ فون، واٹس ایپ اور گوگل میپس کے روابط کاروبار کے فراہم کردہ گوگل میپس پروفائل کے مطابق ہیں۔

## چلانے کا طریقہ / Preview

صرف Python 3 درکار ہے، کسی npm package یا CDN کی ضرورت نہیں:

```bash
python3 build.py
python3 preview_server.py --port 3000
```

Open `http://localhost:3000/`. The preview server creates `robots.txt` and `sitemap.xml` dynamically for the preview host and adds a `noindex` HTTP header so the temporary preview does not compete with the final site. Fonts and images are local; no third-party scripts are required.

## اصل ڈومین پر شائع کرنے سے پہلے / Before deploying

1. Confirm the business name, all service offerings, Google review rating, address, phone/WhatsApp and opening hours with the owner. The listed services were drafted from the business's public profiles; fees are deliberately not stated because public sources disagree. Update `content.py` or page copy in `build.py` as needed.
2. Set the **real public origin** and rebuild, for example:

   ```bash
   python3 build.py --site-url https://your-actual-domain.com
   ```

   This writes absolute canonical URLs, social image URLs, structured-data URLs, a valid XML sitemap, and a robots.txt pointing to that sitemap. Replace the example with the actual domain. Do not index the temporary preview as a substitute for the final site.
3. Upload the generated website files and `assets/` to an HTTPS static host at the origin root. Preserve the `services/<slug>/index.html` folders. `preview_server.py`, `build.py`, and `content.py` are not needed at runtime on a static host, but should be kept as editable source. The site uses root-relative paths and is intended for the root of a domain, not a subfolder.
4. Verify ownership in Google Search Console and submit `https://your-actual-domain.com/sitemap.xml`. Check that the live domain, metadata, robots.txt, WhatsApp and phone links work. Indexing and rankings are controlled by search engines and are not guaranteed.
5. Where possible, update the Google Business Profile website link to the final public URL. Deploying or changing an existing website requires the owner's authorization and hosting access.

## Editing

- Business name, phone, address and map link: `content.py` (`BUSINESS`).
- Service names, descriptions, FAQs, and relationships: `content.py` (`SERVICES`). Each service receives a real separate URL and static HTML page.
- Page layouts, header/footer and local-business/service JSON-LD: `build.py`.
- Colors/layout: `assets/style.css`; mobile menu and WhatsApp form: `assets/app.js`.
- After edits, rebuild with the correct `--site-url`.

The WhatsApp form opens a pre-filled message for the visitor to review and send; this static site does not store those form messages. Google Maps and WhatsApp have their own terms and privacy policies. Architectural and astrolabe photographs are AI-generated decorative imagery, not photographs of the actual business location.

Fonts (Noto Nastaliq Urdu, Manrope, Cormorant Garamond) are distributed under the SIL Open Font License; their license texts are in `assets/fonts/licenses/`.
