(() => {
  const toggle = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('#mobile-navigation');
  const closeMenu = () => {
    if (!toggle || !menu) return;
    toggle.setAttribute('aria-expanded', 'false');
    menu.classList.remove('is-open');
    document.body.classList.remove('menu-open');
  };
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const opening = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(opening));
      menu.classList.toggle('is-open', opening);
      document.body.classList.toggle('menu-open', opening);
    });
    menu.addEventListener('click', event => {
      if (event.target.closest('a')) closeMenu();
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 880) closeMenu();
    });
  }

  const form = document.querySelector('[data-whatsapp-form]');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const name = String(data.get('name') || '').trim();
      const service = String(data.get('service') || '').trim();
      const message = String(data.get('message') || '').trim();
      const lines = [
        'السلام علیکم، مجھے مشاورت کے بارے میں معلومات درکار ہیں۔',
        name ? `نام: ${name}` : '',
        service ? `خدمت: ${service}` : '',
        message ? `میرا سوال: ${message}` : ''
      ].filter(Boolean);
      // The message is not sent to this website. It opens in WhatsApp for review.
      window.location.href = `https://wa.me/923092015876?text=${encodeURIComponent(lines.join('\n'))}`;
    });
  }
})();
