#!/usr/bin/env python3
"""Build a static, indexable Urdu website. Pass --site-url before public deployment."""
import argparse
import html
import json
from datetime import date
from pathlib import Path
from urllib.parse import quote, urlparse

from content import BUSINESS as B, SERVICES

ROOT = Path(__file__).resolve().parent
BY_SLUG = {service['slug']: service for service in SERVICES}
PAGES = ['/', '/services/', '/about/', '/contact/', '/privacy/'] + [f"/services/{s['slug']}/" for s in SERVICES]
SITE_URL = ''

ICONS = {
    'logo': '<path d="M32 4 37 20 52 12 44 27 60 32 44 37 52 52 37 44 32 60 27 44 12 52 20 37 4 32 20 27 12 12 27 20Z"/><circle cx="32" cy="32" r="7"/><path d="M32 23v18M23 32h18"/>',
    'moon': '<path d="M44 12a20 20 0 1 0 8 35A19 19 0 0 1 44 12Z"/><path d="m19 12 1.6 4.4L25 18l-4.4 1.6L19 24l-1.6-4.4L13 18l4.4-1.6Z"/><path d="M48 25v6m-3-3h6"/>',
    'stars': '<circle cx="32" cy="32" r="22"/><circle cx="32" cy="32" r="13"/><path d="M32 6v8M32 50v8M6 32h8M50 32h8M13.5 13.5l5.7 5.7m25.6 25.6 5.7 5.7m0-37-5.7 5.7M19.2 44.8l-5.7 5.7"/><path d="m32 22 2.7 7.3L42 32l-7.3 2.7L32 42l-2.7-7.3L22 32l7.3-2.7Z"/>',
    'rings': '<circle cx="25" cy="34" r="13"/><circle cx="39" cy="34" r="13"/><path d="m21 15 4-5 4 5-4 4Zm18-1v5m-2.5-2.5h5"/>',
    'home': '<path d="M10 30 32 11l22 19M15 27v25h34V27M26 52V37h12v15"/><path d="M25 25h14"/>',
    'chart': '<path d="M12 52h40M16 48V34h7v14m6 0V26h7v22m6 0V17h7v31M14 24l10-6 8 3 13-11"/><path d="m40 10 5-.5.5 5"/>',
    'eye': '<path d="M7 32s9-14 25-14 25 14 25 14-9 14-25 14S7 32 7 32Z"/><circle cx="32" cy="32" r="7"/><circle cx="32" cy="32" r="2"/><path d="M32 8v5m0 38v5M11 16l3 3m39-3-3 3"/>',
    'shield': '<path d="M32 8 51 15v14c0 12-7 20-19 27C20 49 13 41 13 29V15Z"/><path d="m32 21 2.5 6.8 7 2.6-7 2.6L32 40l-2.5-7-7-2.6 7-2.6Z"/>',
    'lantern': '<path d="M25 15h14l3 7v26l-4 6H26l-4-6V22Zm0 0 3-5h8l3 5M22 24h20M22 45h20M28 10V7h8v3M28 28l4-3 4 3v11l-4 3-4-3Z"/>',
    'numbers': '<rect x="11" y="11" width="42" height="42" rx="3"/><path d="M25 20v23m-5-19 5-4m-5 23h10m7-19c1-3 7-4 9 0 2 4-1 6-4 9l-5 6h10"/>',
    'amulet': '<path d="M20 17h24v35H20zM23 17l9-8 9 8M24 25h16M24 45h16"/><path d="m32 28 1.7 4.5 4.5 1.7-4.5 1.7-1.7 4.5-1.7-4.5-4.5-1.7 4.5-1.7Z"/>',
    'dream': '<path d="M40 10a15 15 0 1 0 9 27A15 15 0 0 1 40 10ZM15 47c-1-5 3-9 8-9 2-6 10-7 14-2 6-1 10 3 10 8s-4 8-9 8H22c-4 0-7-2-7-5Z"/><path d="M49 12v6m-3-3h6M16 18v4m-2-2h4"/>',
    'hand': '<path d="M22 32V17a3 3 0 0 1 6 0v11-15a3 3 0 0 1 6 0v15-13a3 3 0 0 1 6 0v15-10a3 3 0 0 1 6 0v19c0 10-6 17-15 17-6 0-10-3-13-8l-7-11a3 3 0 0 1 5-3l6 6Z"/><path d="M27 38c5-2 9 1 11 5M26 45c3 1 6 3 8 6"/>',
    'calendar': '<rect x="12" y="15" width="40" height="38" rx="2"/><path d="M12 26h40M22 10v10M42 10v10M21 33h3m6 0h3m6 0h3M21 41h3m6 0h3m6 0h3"/>',
    'name': '<path d="M13 18h38v32H13zM20 26h24M20 33h17M20 40h21"/><path d="m47 8 1.2 3.3L51.5 12l-3.3 1.2L47 16.5l-1.2-3.3L42.5 12l3.3-.7Z"/>',
    'peace': '<path d="M11 31 32 12l21 19M16 28v24h32V28"/><path d="M32 45c-9-4-8-11-4-12 2-.5 4 1 4 3 0-2 2-3.5 4-3 4 1 5 8-4 12Z"/>',
    'globe': '<circle cx="32" cy="32" r="22"/><path d="M10 32h44M32 10c7 7 10 14 10 22s-3 15-10 22c-7-7-10-14-10-22s3-15 10-22ZM15 20h34M15 44h34"/>',
    'phone': '<path d="M15 8 9 12c-2 2 0 11 9 21s18 12 20 10l5-6-8-7-5 4c-4-2-8-6-10-10l4-5Z" transform="translate(6 3) scale(.9)"/>',
    'whatsapp': '<path d="M32 7a24 24 0 0 0-20.6 36.3L8 56l13-3.3A24 24 0 1 0 32 7Z"/><path d="M23 20c-1.3-.4-2.4.3-3 1.7-1.4 2.9.4 7.3 4.5 11.6s8.8 6.1 11.8 4.7c1.4-.6 2.2-1.8 1.8-3.1l-4.8-3-2.5 2c-2.7-1.4-4.8-3.5-6.1-6.1l1.9-2.6Z"/>',
    'pin': '<path d="M32 56s17-15 17-29a17 17 0 0 0-34 0c0 14 17 29 17 29Z"/><circle cx="32" cy="27" r="6"/>',
    'clock': '<circle cx="32" cy="32" r="23"/><path d="M32 17v16l11 6"/>',
    'arrow': '<path d="M50 32H14m12-12L14 32l12 12"/>',
    'menu': '<path d="M10 19h44M10 32h44M10 45h44"/>',
    'chat': '<path d="M10 12h44v33H30L18 54v-9h-8Z"/><path d="M20 24h24M20 32h18"/>',
    'lock': '<rect x="15" y="28" width="34" height="27" rx="2"/><path d="M22 28V20a10 10 0 0 1 20 0v8M32 38v8"/>',
}


def esc(value):
    return html.escape(str(value), quote=True)


def svg(name, extra=''):
    return f'<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" {extra}>{ICONS[name]}</svg>'


def wa_url(message='السلام علیکم، مجھے مشاورت کے بارے میں معلومات درکار ہیں۔'):
    return f"https://wa.me/{B['phone_digits']}?text={quote(message)}"


def external(url):
    return f'href="{esc(url)}" target="_blank" rel="noopener noreferrer"'


def brand():
    return f'''<a class="brand" href="/" aria-label="{esc(B['name_ur'])} — مرکزی صفحہ">
      <span class="brand-mark">{svg('logo')}</span>
      <span class="brand-text"><span class="brand-name">{esc(B['name_ur'])}</span><span class="brand-sub latin">SPIRITUAL GUIDANCE · LAHORE</span></span>
    </a>'''


def header(active=''):
    links = [('/', 'مرکزی صفحہ', 'home'), ('/services/', 'ہماری خدمات', 'services'), ('/about/', 'ہمارے بارے میں', 'about'), ('/contact/', 'رابطہ', 'contact')]
    nav = ''.join(f'<a href="{url}"' + (' aria-current="page"' if key == active else '') + f'>{label}</a>' for url,label,key in links)
    return f'''<div class="topline"><div class="wrap topline-inner">
      <p class="topline-location">{svg('pin')} جوہر ٹاؤن، لاہور <span aria-hidden="true">·</span> رابطہ ۲۴ گھنٹے</p>
      <a class="topline-phone" href="tel:+{B['phone_digits']}" dir="ltr">CALL / WHATSAPP &nbsp; <strong>{esc(B['phone_display'])}</strong></a>
    </div></div>
    <header class="site-header"><div class="wrap header-inner">
      {brand()}
      <nav class="primary-nav" aria-label="مرکزی نیویگیشن">{nav}</nav>
      <div class="header-actions"><a class="header-call" href="tel:+{B['phone_digits']}">{svg('phone')} براہِ راست کال</a>
      <button class="nav-toggle" type="button" data-menu-toggle aria-label="مینو کھولیں یا بند کریں" aria-expanded="false" aria-controls="mobile-navigation">{svg('menu')}</button></div>
    </div><nav class="mobile-nav" id="mobile-navigation" aria-label="موبائل نیویگیشن">{nav}<a class="mobile-contact" {external(wa_url())}>واٹس ایپ پر رابطہ</a></nav></header>'''


def footer():
    service_links = ''.join(f'<a href="/services/{s["slug"]}/">{esc(s["name"])}</a>' for s in SERVICES[:5])
    return f'''<footer class="site-footer"><div class="wrap footer-main">
      <div class="footer-brand">{brand()}<p>آپ کے سوالات اور زندگی کے اہم معاملات کے لیے روحانی اور نجومی مشاورت۔ احترام، توجہ اور آسان رابطے کے ساتھ۔</p></div>
      <div class="footer-col"><h3>آسان روابط</h3><a href="/">مرکزی صفحہ</a><a href="/services/">تمام خدمات</a><a href="/about/">ہمارے بارے میں</a><a href="/contact/">رابطہ کیجیے</a><a href="/privacy/">رازداری</a></div>
      <div class="footer-col"><h3>نمایاں خدمات</h3>{service_links}<a href="/services/">تمام خدمات دیکھیے ←</a></div>
      <div class="footer-col"><h3>ہم سے رابطہ</h3><p>{esc(B['address_ur'])}</p><a class="footer-phone" dir="ltr" href="tel:+{B['phone_digits']}">{esc(B['phone_display'])}</a><a {external(B['maps'])}>گوگل میپس پر راستہ دیکھیے ←</a><a {external(wa_url())}>واٹس ایپ پر پیغام بھیجیں</a></div>
    </div><div class="footer-divider"><div class="wrap footer-bottom"><p>روحانی مشاورت طبی، نفسیاتی، مالی یا قانونی مشورے کا متبادل نہیں۔ نتائج کی ضمانت نہیں۔</p><span class="latin">© {date.today().year} {esc(B['name_en'])}</span></div></div></footer>
    <a class="whatsapp-float" {external(wa_url())} aria-label="واٹس ایپ پر رابطہ">{svg('whatsapp')}</a>
    <div class="mobile-quick" aria-label="فوری رابطہ"><a {external(wa_url())}>{svg('whatsapp')} واٹس ایپ</a><a href="tel:+{B['phone_digits']}">{svg('phone')} ابھی کال کریں</a></div>'''


def business_schema():
    data = {
        '@type': 'LocalBusiness',
        'name': B['name_en'] + ' – Spiritual Healer & Astrologer',
        'alternateName': B['name_ur'],
        'description': 'Astrology, istikhara and spiritual consultation in Johar Town, Lahore, and online.',
        'telephone': '+923092015876',
        'address': {'@type':'PostalAddress','streetAddress':'Johar Town Road, Block H-2, Phase 2, Johar Town','addressLocality':'Lahore','addressRegion':'Punjab','addressCountry':'PK'},
        'openingHoursSpecification': [{'@type':'OpeningHoursSpecification','dayOfWeek':['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],'opens':'00:00','closes':'23:59'}],
        'sameAs': [B['maps']],
    }
    if SITE_URL:
        data['url'] = SITE_URL + '/'
        data['image'] = SITE_URL + '/assets/og-cover.jpg'
    return data


def document(title, description, path, content, active='', service=None, noindex=False):
    canonical = SITE_URL + path if SITE_URL else path
    image = SITE_URL + '/assets/og-cover.jpg' if SITE_URL else '/assets/og-cover.jpg'
    schema = business_schema()
    schema['@context'] = 'https://schema.org'
    graphs = [schema]
    if service:
        provider = business_schema()
        graphs.append({'@context':'https://schema.org','@type':'Service','name':service['name'],'serviceType':service['english'].title(),'description':service['summary'],'provider':provider,'areaServed':{'@type':'Place','name':'Lahore, Pakistan'}})
    jsonld = '\n'.join('<script type="application/ld+json">'+json.dumps(graph, ensure_ascii=False, separators=(',',':')).replace('</','<\\/')+'</script>' for graph in graphs)
    return f'''<!doctype html>
<html lang="ur" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title><meta name="description" content="{esc(description)}">
<meta name="robots" content="{'noindex,follow' if noindex else 'index,follow,max-image-preview:large'}"><link rel="canonical" href="{esc(canonical)}">
<meta property="og:locale" content="ur_PK"><meta property="og:type" content="website"><meta property="og:site_name" content="{esc(B['name_ur'])}"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(description)}"><meta property="og:url" content="{esc(canonical)}"><meta property="og:image" content="{esc(image)}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta name="twitter:card" content="summary_large_image"><meta name="theme-color" content="#0a2119">
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml"><link rel="preload" href="/assets/fonts/NotoNastaliqUrdu-Regular.woff2" as="font" type="font/woff2" crossorigin><link rel="stylesheet" href="/assets/style.css">
<script>document.documentElement.classList.add('js')</script>{jsonld}</head><body>
<a class="skip-link" href="#main">مرکزی مواد پر جائیں</a>{header(active)}<main id="main">{content}</main>{footer()}<script src="/assets/app.js" defer></script></body></html>'''


def service_card(s, index=None):
    if index is None: index = SERVICES.index(s) + 1
    return f'''<a class="service-card" href="/services/{esc(s['slug'])}/" aria-label="{esc(s['name'])} کی تفصیل دیکھیے">
      <div class="card-top"><span class="card-icon">{svg(s['icon'])}</span><span class="card-number" aria-hidden="true">{index:02d}</span></div>
      <h3>{esc(s['name'])}</h3><p>{esc(s['summary'])}</p>
      <div class="card-bottom"><span>مزید جانیے</span><span class="card-english">{esc(s['english'])}</span>{svg('arrow')}</div>
    </a>'''


def faq_list(items):
    return '<div class="faq-list">' + ''.join(f'<details><summary>{esc(q)}</summary><p>{esc(a)}</p></details>' for q,a in items) + '</div>'


def cta_section():
    return f'''<section class="cta-section"><div class="wrap cta-inner"><div><span class="eyebrow">A CONVERSATION CAN BE THE FIRST STEP</span><h2>اپنی بات کیجیے، رہنمائی حاصل کیجیے</h2><p>جوہر ٹاؤن، لاہور سے فون اور واٹس ایپ پر رابطہ۔</p></div><a class="button button-dark" {external(wa_url())}>{svg('whatsapp')} واٹس ایپ پر بات کیجیے</a></div></section>'''


def breadcrumb(items):
    out = '<nav class="breadcrumb" aria-label="صفحے کا راستہ"><a href="/">مرکزی صفحہ</a>'
    for label, url in items:
        out += '<span aria-hidden="true">/</span>'
        out += f'<a href="{esc(url)}">{esc(label)}</a>' if url else f'<span aria-current="page">{esc(label)}</span>'
    return out + '</nav>'


def home_page():
    cards = ''.join(service_card(s) for s in SERVICES[:6])
    faq = faq_list([
        ('آپ کہاں موجود ہیں؟', 'ہمارا پتہ جوہر ٹاؤن روڈ، بلاک ایچ ٹو، فیز ۲، جوہر ٹاؤن، لاہور ہے۔ ملاقات سے پہلے فون یا واٹس ایپ پر وقت کی تصدیق کر لیجیے۔'),
        ('کیا بیرونِ شہر یا بیرونِ ملک سے رابطہ ہو سکتا ہے؟', 'جی ہاں، پاکستان اور بیرونِ ملک سے فون یا واٹس ایپ کے ذریعے آن لائن رابطہ کیا جا سکتا ہے۔'),
        ('رابطے کا وقت اور فیس کیا ہے؟', 'گوگل میپس پروفائل پر ۲۴ گھنٹے دستیابی درج ہے۔ مخصوص مشاورت کے وقت اور فیس کی تصدیق براہِ راست رابطے پر کر لیجیے۔'),
        ('مشاورت کے لیے کون سی معلومات درکار ہیں؟', 'یہ خدمت کے مطابق مختلف ہو سکتی ہیں۔ ابتدا میں صرف اپنا سوال بتائیں؛ مطلوبہ تفصیلات رابطے پر دریافت کر لیجیے۔')
    ])
    return f'''<section class="hero" aria-labelledby="hero-title"><div class="wrap hero-inner"><div class="hero-content">
      <span class="hero-kicker"><span class="spark">✦</span> روحانی مشاورت کا ایک باوقار انداز</span>
      <h1 id="hero-title"><span>زندگی کے سفر میں</span> <span class="gold-3d">رہنمائی کا نور</span></h1>
      <p class="hero-lede"><strong>{esc(B['name_ur'])}</strong> کے ساتھ رشتوں، فیصلوں اور زندگی کے اہم معاملات پر روحانی و نجومی مشاورت۔</p>
      <p class="hero-english" lang="en" dir="ltr">Astrologer &amp; Spiritual Guidance · Johar Town, Lahore</p>
      <div class="hero-actions"><a class="button button-gold" {external(wa_url())}>{svg('whatsapp')} واٹس ایپ پر رابطہ</a><a class="button button-outline-light" href="/services/">ہماری خدمات دیکھیے {svg('arrow')}</a></div>
    </div></div><div class="hero-caption" aria-hidden="true"><div><strong>Guidance with dignity.</strong><span>Johar Town · Lahore</span></div></div><div class="hero-side-label" aria-hidden="true">A MOMENT OF CLARITY · EST. IN LAHORE</div></section>
    <div class="trust-strip"><div class="wrap trust-inner">
      <div class="trust-item">{svg('clock')}<div><strong>۲۴ گھنٹے رابطہ</strong><small>فون اور واٹس ایپ</small></div></div>
      <div class="trust-item">{svg('lock')}<div><strong>ذاتی مشاورت</strong><small>احترام اور توجہ کے ساتھ</small></div></div>
      <div class="trust-item">{svg('pin')}<div><strong>جوہر ٹاؤن، لاہور</strong><small>گوگل میپس پر موجود</small></div></div>
      <a class="trust-item" {external(B['maps'])}>{svg('stars')}<div><strong class="trust-rating">4.8 / 5</strong><small>گوگل ریویوز · اکتوبر ۲۰۲۶</small></div></a>
    </div></div>
    <section class="section section-paper" id="services"><div class="wrap">
      <div class="section-heading"><div><span class="eyebrow">A THOUGHTFUL APPROACH TO YOUR QUESTIONS</span><h2>آپ کے لیے ہماری خدمات</h2><p>ہر سوال الگ ہے، اسی لیے ہر خدمت کے لیے ایک الگ صفحہ اور واضح معلومات موجود ہیں۔</p></div><a class="text-link" href="/services/">تمام ۱۶ خدمات دیکھیے {svg('arrow')}</a></div>
      <div class="service-grid">{cards}</div><div class="services-foot"><p>ان کے علاوہ مزید روحانی و نجومی مشاورت کے لیے تمام خدمات ملاحظہ کیجیے۔</p><a class="button button-outline-dark" href="/services/">تمام خدمات دیکھیں {svg('arrow')}</a></div>
    </div></section>
    <section class="section about-section"><div class="wrap about-grid"><div class="about-copy"><span class="eyebrow light">A PRACTICE BUILT AROUND LISTENING</span><h2>ہر بات کے پیچھے<br><span class="gold-3d">ایک کہانی ہوتی ہے</span></h2><p>زندگی میں کبھی کوئی رشتہ، فیصلہ یا نیا راستہ بہت سے سوالات ساتھ لاتا ہے۔ ایسے لمحوں میں اپنی بات کہنے اور رہنمائی حاصل کرنے کے لیے ایک باوقار جگہ اہم ہوتی ہے۔</p><p><span class="name-accent">{esc(B['name_ur'])}</span>، جوہر ٹاؤن لاہور سے استخارہ، علمِ نجوم اور روحانی مشاورت کے لیے رابطے کی سہولت فراہم کرتے ہیں۔</p><a class="button button-outline-light" href="/about/">ہمارے بارے میں جانیے {svg('arrow')}</a><div class="about-signature">{svg('logo')}<div><strong>{esc(B['name_ur'])}</strong><small>روحانی مشاورت اور علمِ نجوم · لاہور</small></div></div></div>
      <div class="about-visual"><img src="/assets/arch-courtyard.webp" alt="محرابی دروازے اور پُرسکون صحن کی علامتی تصویر" loading="lazy" width="768" height="1376"><div class="photo-tag"><strong>A quieter moment.</strong><small>علامتی منظر · ایک پُرسکون آغاز</small></div></div></div></section>
    <section class="section section-white"><div class="wrap"><div class="section-heading"><div><span class="eyebrow">SIMPLE, PERSONAL, DIRECT</span><h2>رابطے سے مشاورت تک</h2><p>پہلا قدم صرف ایک گفتگو ہے۔ اپنی سہولت کے مطابق رابطہ کیجیے۔</p></div><span class="section-number">01 — 03</span></div>
      <div class="process-grid"><div class="process-step"><span class="process-num">01</span><h3>رابطہ کیجیے</h3><p>فون یا واٹس ایپ پر اپنے لیے آسان وقت میں پیغام بھیجیے۔</p></div><div class="process-step"><span class="process-num">02</span><h3>اپنا سوال بتائیے</h3><p>جس معاملے پر بات کرنا چاہتے ہیں، اسے مختصراً بیان کیجیے۔</p></div><div class="process-step"><span class="process-num">03</span><h3>تفصیلات طے کیجیے</h3><p>مشاورت کا طریقہ، وقت اور فیس پہلے معلوم کر لیجیے۔</p></div></div>
    </div></section>
    <section class="review-section"><div class="wrap review-grid"><div class="review-head"><div class="review-score">4.8</div><div><div class="review-stars" aria-label="گوگل پر ۵ میں سے ۴ اعشاریہ ۸">★★★★★</div><h2>گوگل پر لوگوں کی آراء</h2><p>گوگل میپس پروفائل کے مطابق · اکتوبر ۲۰۲۶</p></div></div><a class="button button-outline-light" {external(B['maps'])}>گوگل میپس پر دیکھیے {svg('arrow')}</a></div></section>
    <section class="section section-paper"><div class="wrap faq-grid"><div class="faq-copy"><span class="eyebrow">A LITTLE MORE CLARITY</span><h2>اکثر پوچھے جانے والے سوالات</h2><p>اگر آپ کا سوال یہاں موجود نہیں تو ہم سے براہِ راست بات کیجیے۔</p><a class="text-link" href="/contact/">رابطہ کی تفصیلات {svg('arrow')}</a></div>{faq}</div></section>
    {cta_section()}'''


def services_page():
    return f'''<section class="page-hero"><div class="wrap">{breadcrumb([('ہماری خدمات',None)])}<span class="eyebrow light">OUR SERVICES · EXPLORE ALL 16</span><h1>آپ کے سوال، ہماری خدمات</h1><p>استخارہ اور زائچے سے لے کر رشتوں، کاروبار اور روحانی رہنمائی تک — اپنی ضرورت کی خدمت منتخب کیجیے اور اس کا الگ صفحہ دیکھیے۔</p></div></section>
    <section class="section section-paper services-all"><div class="wrap"><div class="section-heading"><div><span class="eyebrow">A PERSONAL SPACE FOR GUIDANCE</span><h2>تمام خدمات ایک نظر میں</h2><p>ہر خدمت کے صفحے پر مزید تفصیلات، عام سوالات اور براہِ راست رابطہ موجود ہے۔</p></div><span class="section-number">01 — 16</span></div><div class="service-grid">{''.join(service_card(s) for s in SERVICES)}</div></div></section>{cta_section()}'''


def service_page(s):
    name, summary = s['name'], s['summary']
    message = f"السلام علیکم، مجھے {name} کے بارے میں مشاورت اور فیس کی معلومات درکار ہیں۔"
    points = ''.join(f'<li>{esc(p)}</li>' for p in s['points'])
    related = ''.join(service_card(BY_SLUG[slug]) for slug in s['related'])
    return f'''<section class="page-hero"><div class="wrap">{breadcrumb([('ہماری خدمات','/services/'),(name,None)])}<div class="service-hero-grid"><div class="page-hero-copy"><span class="eyebrow light">{esc(s['english'])} · LAHORE</span><h1>{esc(name)}</h1><p>{esc(summary)} جوہر ٹاؤن، لاہور سے فون یا واٹس ایپ پر رابطہ کیجیے۔</p><div class="hero-actions"><a class="button button-gold" {external(wa_url(message))}>{svg('whatsapp')} اس خدمت کے لیے رابطہ</a><a class="button button-outline-light" href="tel:+{B['phone_digits']}">{svg('phone')} براہِ راست کال</a></div></div><div class="service-seal" aria-hidden="true"><span class="seal-top">GUIDANCE · LAHORE</span>{svg(s['icon'])}<span class="seal-bottom">EST. IN LAHORE</span></div></div></div></section>
    <section class="inner-content section-white"><div class="wrap service-layout"><article class="prose"><span class="eyebrow">A MORE PERSONAL CONVERSATION</span><h2>{esc(name)} کے بارے میں</h2><p>{esc(s['intro'])}</p><p>{esc(s['detail'])}</p><div class="prose-rule"></div><h2>آپ کن سوالات پر بات کر سکتے ہیں؟</h2><ul class="check-list">{points}</ul><div class="notice">مشاورت کا طریقہ، دستیابی اور فیس رابطے پر معلوم کریں۔ روحانی و نجومی مشاورت کسی مستند طبی، نفسیاتی، مالی یا قانونی مشورے کا متبادل نہیں۔</div><div class="service-faq"><h2>عام سوالات</h2>{faq_list(s['faqs'])}</div></article>
    <aside class="booking-card"><span class="eyebrow">LET’S TALK</span><h2>اپنی بات کیجیے</h2><p>اپنے سوال کے ساتھ براہِ راست رابطہ کریں۔ مشاورت کی تفصیلات اور فیس پہلے معلوم کی جا سکتی ہیں۔</p><a class="button button-gold" {external(wa_url(message))}>{svg('whatsapp')} واٹس ایپ پر پیغام</a><a class="button button-outline-light" href="tel:+{B['phone_digits']}">{svg('phone')} کال کیجیے</a><div class="mini-contact"><span>جوہر ٹاؤن، لاہور · فون / واٹس ایپ</span><a href="tel:+{B['phone_digits']}" dir="ltr">{esc(B['phone_display'])}</a></div></aside></div></section>
    <section class="related-section"><div class="wrap"><span class="eyebrow">CONTINUE EXPLORING</span><h2>متعلقہ خدمات</h2><div class="service-grid">{related}</div></div></section>{cta_section()}'''


def about_page():
    return f'''<section class="page-hero"><div class="wrap">{breadcrumb([('ہمارے بارے میں',None)])}<span class="eyebrow light">A MORE THOUGHTFUL APPROACH</span><h1>توجہ سے سننا، احترام سے رہنمائی</h1><p>ایک باوقار گفتگو کبھی کبھی زندگی کے اہم سوالات پر سوچنے کا پہلا قدم ہوتی ہے۔</p></div></section>
    <section class="inner-content section-paper"><div class="wrap about-page-grid"><article class="prose"><span class="eyebrow">ABOUT THE PRACTICE</span><h2>{esc(B['name_ur'])}</h2><p>جوہر ٹاؤن، لاہور میں قائم اس مشاورت کا مرکز زندگی کے مختلف معاملات پر روحانی اور نجومی رہنمائی ہے۔ رشتہ و شادی، زائچہ، استخارہ، کاروبار اور گھریلو معاملات کے بارے میں اپنی بات بیان کرنے کے لیے رابطہ کیا جا سکتا ہے۔</p><p>ہر شخص کی صورتحال مختلف ہوتی ہے۔ اس لیے اپنی ضرورت، طریقۂ کار، دستیابی اور فیس کے بارے میں گفتگو پہلے کر لیجیے۔ فون اور واٹس ایپ پر پاکستان اور بیرونِ ملک سے رابطہ ممکن ہے۔</p><h3>ہماری سوچ</h3><ul class="check-list"><li>آپ کی بات توجہ اور احترام سے سنی جائے۔</li><li>ہر خدمت کی تفصیلات اور فیس پہلے واضح کی جائے۔</li><li>کوئی بھی نتیجہ یقینی قرار دینے کے بجائے باخبر فیصلہ کیا جائے۔</li></ul><div class="notice">صحت، ذہنی صحت، مالی اور قانونی معاملات میں متعلقہ مستند ماہر کی مدد حاصل کرنا اہم ہے۔</div><p style="margin-top:25px"><a class="button button-outline-dark" href="/contact/">رابطہ کی تفصیلات {svg('arrow')}</a></p></article><div class="about-visual"><img src="/assets/arch-courtyard.webp" alt="محراب اور صحن کی علامتی تصویر" width="768" height="1376" loading="lazy"><div class="photo-tag"><strong>Johar Town, Lahore</strong><small>علامتی منظر · لاہور سے آپ تک</small></div></div></div></section>{cta_section()}'''


def contact_page():
    options = '<option value="">اپنی ضرورت منتخب کریں</option>' + ''.join(f'<option value="{esc(s["name"])}">{esc(s["name"])}</option>' for s in SERVICES) + '<option value="دیگر سوال">دیگر سوال</option>'
    return f'''<section class="page-hero"><div class="wrap">{breadcrumb([('رابطہ',None)])}<span class="eyebrow light">WE ARE HERE TO LISTEN</span><h1>آئیے، بات کرتے ہیں</h1><p>اپنا سوال براہِ راست واٹس ایپ یا فون پر بتائیے، یا جوہر ٹاؤن لاہور میں ملاقات کا وقت معلوم کیجیے۔</p></div></section>
    <section class="inner-content section-paper"><div class="wrap contact-grid"><div class="contact-card"><span class="eyebrow">SEND A WHATSAPP MESSAGE</span><h2>اپنا پیغام لکھیے</h2><p>نیچے دی گئی معلومات سے ایک پیغام تیار ہوگا، جسے آپ واٹس ایپ پر دیکھ کر خود بھیج سکیں گے۔</p><form class="js-form" data-whatsapp-form action="https://wa.me/{B['phone_digits']}" method="get"><div class="form-row"><label for="name">آپ کا نام <small>(اختیاری)</small></label><input id="name" name="name" type="text" maxlength="80" placeholder="اپنا نام لکھیے" autocomplete="name"></div><div class="form-row"><label for="service">کس خدمت کے بارے میں؟</label><select id="service" name="service" required>{options}</select></div><div class="form-row"><label for="message">آپ کا سوال</label><textarea id="message" name="message" maxlength="1200" required placeholder="اپنا سوال مختصراً لکھیے"></textarea></div><button class="button button-gold js-only" type="submit">{svg('whatsapp')} واٹس ایپ پر پیغام کھولیں</button><p class="form-note">یہ ویب سائٹ آپ کا پیغام محفوظ نہیں کرتی۔ بٹن دبانے پر واٹس ایپ کھلے گا؛ پیغام آپ خود بھیجیں گے۔ حساس تفصیلات صرف اپنی مرضی سے شیئر کیجیے۔</p></form><div class="no-js-only"><p class="form-note">فارم استعمال کرنے کے لیے جاوا اسکرپٹ درکار ہے۔ آپ براہِ راست واٹس ایپ کے ذریعے رابطہ کر سکتے ہیں۔</p><a class="button button-gold" {external(wa_url())}>{svg('whatsapp')} براہِ راست واٹس ایپ کھولیں</a></div></div>
    <div class="contact-points"><div class="contact-point"><span class="contact-icon">{svg('phone')}</span><div><h3>فون اور واٹس ایپ</h3><a class="latin-phone" href="tel:+{B['phone_digits']}" dir="ltr">{esc(B['phone_display'])}</a><a {external(wa_url())}>واٹس ایپ پر براہِ راست پیغام ←</a></div></div><div class="contact-point"><span class="contact-icon">{svg('pin')}</span><div><h3>ہمارا پتہ</h3><p>{esc(B['address_ur'])}</p><a {external(B['maps'])}>گوگل میپس پر راستہ دیکھیے ←</a></div></div><div class="contact-point"><span class="contact-icon">{svg('clock')}</span><div><h3>رابطے کا وقت</h3><p>گوگل میپس پر ۲۴ گھنٹے درج ہے۔ ملاقات سے پہلے وقت کی تصدیق کر لیجیے۔</p></div></div><div class="contact-point"><span class="contact-icon">{svg('globe')}</span><div><h3>آن لائن مشاورت</h3><p>پاکستان اور بیرونِ ملک سے فون یا واٹس ایپ پر رابطہ کیجیے۔</p></div></div><a class="text-link" href="/privacy/">رازداری کے بارے میں پڑھیے {svg('arrow')}</a></div></div></section>{cta_section()}'''


def privacy_page():
    return f'''<section class="page-hero"><div class="wrap">{breadcrumb([('رازداری',None)])}<span class="eyebrow light">YOUR PRIVACY MATTERS</span><h1>رازداری اور رابطے کے بارے میں</h1><p>اس ویب سائٹ کے رابطے کے طریقوں کی سادہ وضاحت۔</p></div></section><section class="inner-content section-white"><div class="wrap"><article class="prose privacy-copy"><h2>رابطے کا فارم کیسے کام کرتا ہے؟</h2><p>رابطے کے صفحے پر لکھی گئی معلومات آپ کے براؤزر میں ایک پیغام بناتی ہیں اور واٹس ایپ کھولتی ہیں۔ یہ ویب سائٹ آپ کے فارم کا پیغام کسی سرور یا ڈیٹابیس میں محفوظ نہیں کرتی۔ آپ پیغام واٹس ایپ پر خود دیکھ کر بھیجتے ہیں۔</p><h2>بیرونی خدمات</h2><p>واٹس ایپ، فون یا گوگل میپس کے روابط استعمال کرنے پر آپ متعلقہ سروس کی طرف جاتے ہیں، جہاں اس سروس کی اپنی شرائط اور رازداری کی پالیسی لاگو ہوتی ہے۔ حساس ذاتی معلومات صرف اپنی رضامندی سے شیئر کیجیے۔</p><h2>سوالات</h2><p>رازداری یا رابطے سے متعلق سوال کے لیے <a class="text-link" href="tel:+{B['phone_digits']}">{esc(B['phone_display'])}</a> پر کال کریں۔</p></article></div></section>{cta_section()}'''


def not_found():
    return '''<section class="section-paper not-found"><div><span class="eyebrow">PAGE NOT FOUND</span><h1>یہ صفحہ نہیں ملا</h1><p>براہِ کرم مرکزی صفحے یا خدمات کی فہرست پر واپس جائیے۔</p><a class="button button-outline-dark" href="/">مرکزی صفحہ</a></div></section>'''


def write_page(path, text):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding='utf-8')


def main():
    global SITE_URL
    parser = argparse.ArgumentParser(description='Build the static website; use --site-url for the final public domain.')
    parser.add_argument('--site-url', default='', help='Production origin, e.g. https://example.com (no trailing path)')
    args = parser.parse_args()
    if args.site_url:
        parsed = urlparse(args.site_url)
        if parsed.scheme not in ('http','https') or not parsed.netloc or parsed.path not in ('','/') or parsed.query or parsed.fragment:
            parser.error('--site-url must be a full domain origin, e.g. https://example.com')
        SITE_URL = f'{parsed.scheme}://{parsed.netloc}'
    write_page('index.html', document('عامل بابا نعمان علی شاہ | Astrologer & Istikhara in Lahore', 'جوہر ٹاؤن لاہور میں استخارہ، زائچہ، رشتوں اور روحانی مشاورت کے لیے رابطہ کریں۔ Syed Numan Ali Shah — astrologer in Lahore.', '/', home_page(), 'home'))
    write_page('services/index.html', document('تمام خدمات | استخارہ، زائچہ اور روحانی مشاورت لاہور', 'جوہر ٹاؤن لاہور میں عامل بابا نعمان علی شاہ کی تمام روحانی اور نجومی خدمات دیکھیے۔ ہر خدمت کا الگ صفحہ اور براہِ راست رابطہ۔', '/services/', services_page(), 'services'))
    for service in SERVICES:
        path = f"/services/{service['slug']}/"
        title = f"{service['name']} لاہور | {service['english'].title()} | Numan Ali Shah"
        description = f"{service['summary']} جوہر ٹاؤن لاہور یا آن لائن رابطہ کریں۔ {service['english'].title()} in Lahore. Call 0309 2015876."
        write_page(f"services/{service['slug']}/index.html", document(title, description, path, service_page(service), 'services', service))
    write_page('about/index.html', document('ہمارے بارے میں | عامل بابا نعمان علی شاہ لاہور', 'عامل بابا نعمان علی شاہ کی روحانی اور نجومی مشاورت، جوہر ٹاؤن لاہور، اور رابطے کے طریقوں کے بارے میں جانیے۔', '/about/', about_page(), 'about'))
    write_page('contact/index.html', document('رابطہ | عامل بابا نعمان علی شاہ، جوہر ٹاؤن لاہور', 'روحانی مشاورت اور استخارہ کے لیے عامل بابا نعمان علی شاہ سے 0309 2015876 پر کال یا واٹس ایپ کریں۔ جوہر ٹاؤن، لاہور۔', '/contact/', contact_page(), 'contact'))
    write_page('privacy/index.html', document('رازداری | عامل بابا نعمان علی شاہ', 'ہماری ویب سائٹ کے واٹس ایپ رابطے اور بیرونی خدمات کے استعمال سے متعلق رازداری کی معلومات۔', '/privacy/', privacy_page()))
    write_page('404.html', document('صفحہ نہیں ملا | عامل بابا نعمان علی شاہ', 'مطلوبہ صفحہ دستیاب نہیں۔ ہماری خدمات دیکھیے یا رابطہ کیجیے۔', '/404.html', not_found(), noindex=True))
    if SITE_URL:
        xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join(f'  <url><loc>{esc(SITE_URL + p)}</loc></url>\n' for p in PAGES) + '</urlset>\n'
        write_page('sitemap.xml', xml)
        write_page('robots.txt', f'User-agent: *\nAllow: /\nSitemap: {SITE_URL}/sitemap.xml\n')
    else:
        # A sitemap needs absolute URLs; the preview server provides one dynamically.
        (ROOT / 'sitemap.xml').unlink(missing_ok=True)
        write_page('robots.txt', 'User-agent: *\nAllow: /\n')
    print(f'Built {len(PAGES)} indexable pages' + (f' for {SITE_URL}' if SITE_URL else ' for preview (set --site-url before publishing)'))


if __name__ == '__main__':
    main()
